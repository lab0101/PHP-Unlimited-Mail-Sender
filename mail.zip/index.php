<!DOCTYPE html>
<html>
<body>


<div style="width: 400px;margin:30px auto;background: #eee;padding: 0px 30px 20px">
<h3 style="text-align: center;background: tomato;padding: 5px">Send Unlimited Mail</h3>
<form action="send.php" method="post">
Receiver Email:<br>
<input type="text" name="email">
<br>
<br>
Subject:<br>
<input type="text" name="sub">
<br>
<br>
Message:<br>
<textarea name="msg" rows="5" cols="30"></textarea>
<!-- <input type="text" name="msg"> -->
<br>
<br>
Send Quantity:<br>
<input type="number" value="1" min="1" name="total">
<br>
<br>
<input type="submit" name="send" value="Send">
</form>

</div>
</body>
</html>