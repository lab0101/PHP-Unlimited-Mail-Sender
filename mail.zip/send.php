<?php 



$total = $_POST['total'];
$email = $_POST['email'];
$sub = $_POST['sub'];
$msg = $_POST['msg'];

for($i=1; $i<=$total;$i++){
    $sender="tufayalhossin".$i."@gmail.com";
    if($email != "tufayalhossin95@gmail.com"){
    if(mail($email,$sub.$i,$msg ,"from:".$sender)){
        if($i==$total){
            echo "<p style='color:green'>Message send Successfully</p>";
           echo "<a href='index.php'>Go Back</a>";
        }
    }else{
            echo "<p style='color:red'>Oops! Message not send. something is wrong</p>";
            echo "<a href='index.php'>Try Again</a>";
    }
    }else{
        echo "this email block.";
    }
    
}